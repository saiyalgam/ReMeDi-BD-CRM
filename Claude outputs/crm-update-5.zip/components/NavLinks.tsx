'use client';
import Link from 'next/link';
import type { ReactNode } from 'react';
import { usePathname, useSearchParams } from 'next/navigation';

export interface NavItem { href: string; label: string; count?: number; color?: string; icon?: ReactNode; match?: string; alert?: boolean }

export function NavLinks({ title, items }: { title: string; items: NavItem[] }) {
  const path = usePathname();
  const sp = useSearchParams();
  const current = path + (sp.toString() ? '?' + sp.toString() : '');
  const isActive = (it: NavItem) => {
    if (it.match) return path === it.match || path.startsWith(it.match + '/');
    const [p, q] = it.href.split('?');
    if (p !== path) return false;
    if (!q) return !sp.get('type') && !sp.get('assignee') && !sp.get('q');
    return new URLSearchParams(q).toString().split('&').every(kv => current.includes(kv));
  };
  return (
    <nav className="navgroup" aria-label={title}>
      <small>{title}</small>
      {items.map(it => (
        <Link key={it.href} href={it.href} className="navlink" aria-current={isActive(it) ? 'page' : undefined}>
          <span className="lbl">{it.icon}{it.color ? <i className="dot" style={{ background: it.color }} aria-hidden="true" /> : null}{it.label}</span>
          {it.count != null ? <span className={`count${it.alert ? ' alert' : ''}`}>{it.count}{it.alert ? ' due' : ''}</span> : null}
        </Link>
      ))}
    </nav>
  );
}
